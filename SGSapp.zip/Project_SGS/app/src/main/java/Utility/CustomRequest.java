package Utility;

public interface CustomRequest {

    void handleResponse(Object response);
}
